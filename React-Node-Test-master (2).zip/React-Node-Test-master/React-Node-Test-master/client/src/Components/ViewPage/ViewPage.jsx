import React from 'react'
import Topbar from './Topbar'

const ViewPage = () => {
  return (
    <div className='h-full w-full'>
        <Topbar />
    </div>
  )
}

export default ViewPage